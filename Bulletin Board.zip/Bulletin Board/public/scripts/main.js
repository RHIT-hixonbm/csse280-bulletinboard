// Namespace
var rhit = rhit || {};

//Singletons
rhit.fbAuth = null;
rhit.fbUserManager = null;
rhit.fbPostsManager = null;
rhit.fbSinglePostManager = null;
rhit.fbMessageManager = null;
rhit.profilePageController = null;

//Firebase keys
rhit.FB_KEY_USERS_COLLECTION = "users";
rhit.FB_KEY_USERS_BIO = "bio";
rhit.FB_KEY_USERS_CAMPUS = "campus";
rhit.FB_KEY_USERS_FOLLOWING = "following";
rhit.FB_KEY_USERS_HAS_MESSAGES = "hasMessagesWith";
rhit.FB_KEY_USERS_IS_MODERATOR = "isModerator";
rhit.FB_KEY_USERS_LAST_EDITED = "lastEdited";
rhit.FB_KEY_USERS_NAME = "name";
rhit.FB_KEY_USERS_PROFILE_IMG_SRC = "profileImgUrl";
rhit.FB_KEY_USERS_RATINGS = "rating";
rhit.FB_KEY_POSTS_COLLECTION = "posts";
rhit.FB_KEY_POSTS_AUTHOR = "author";
rhit.FB_KEY_POSTS_DESCRIPTION = "description";
rhit.FB_KEY_POSTS_HASTAGS = "hashtags";
rhit.FB_KEY_POSTS_IMAGE_URL = "imageUrl";
rhit.FB_KEY_POSTS_LAST_EDITED = "lastEdited";
rhit.FB_KEY_POSTS_TITLE = "title";
rhit.FB_KEY_POSTS_EXPIRATION = "expirationDate";
rhit.FB_KEY_MESSAGES_COLLECTION = "messages";
rhit.FB_KEY_MESSAGES_MESSAGES = "messages";

//Other keys
rhit.FB_POSTS_CALLER = "fbPosts";
rhit.FB_USER_CALLER = "fbUser";
rhit.FB_SINGLE_POST_CALLER = "fbSinglePost";
rhit.FB_MESSAGE_CALLER = "fbMessage";

//Page Controller Helpers
rhit._initializeSidebar = () => {
	document.querySelector("#menuProfileButton").addEventListener("click", () => {
		window.location.href = `/profile.html?uid=${rhit.fbAuth.uid}`;
	});
	document.querySelector("#menuPostsButton").addEventListener("click", () => {
		window.location.href = `/posts.html`;
	});
	document.querySelector("#menuMessagesButton").addEventListener("click", () => {
		window.location.href = `/messageList.html`;
	});
	document.querySelector("#menuFollowingButton").addEventListener("click", () => {
		window.location.href = `/following.html`
	});
	document.querySelector("#menuSignOutButton").addEventListener("click", () => {
		rhit.fbAuth.signOut();
	});
}
rhit._intializeStarButtons = () => {
	document.querySelector("#star1Button").onclick = (event) => {
		rhit.fbUserManager.updateRating(1);
	}
	document.querySelector("#star2Button").onclick = (event) => {
		rhit.fbUserManager.updateRating(2);
	}
	document.querySelector("#star3Button").onclick = (event) => {
		rhit.fbUserManager.updateRating(3);
	}
	document.querySelector("#star4Button").onclick = (event) => {
		rhit.fbUserManager.updateRating(4);
	}
	document.querySelector("#star5Button").onclick = (event) => {
		rhit.fbUserManager.updateRating(5);
	}
}
rhit._initializeFollowButton = (pageUpdater) => {
	rhit.fbUserManager.isFollowingUser().
		then((followingStatus) => {
			document.querySelector("#followButton").onclick = () => {
				if(followingStatus) {
					rhit.fbUserManager.unfollow().then(() => {
						rhit.profilePageController.updateView(rhit.FB_USER_CALLER);
					});
				} else {
					rhit.fbUserManager.follow().then(() => {
						rhit.profilePageController.updateView(rhit.FB_USER_CALLER);
					});
				}	
			}
	});
}
rhit._ensureUserIsValid = () => {
	rhit.fbUserManager._documentPromise().then((docSnap) => {
		if(!docSnap.exists) {
			window.location.href = "/404.html";
		}
	})
}
rhit._showPage = (pageId) => {
	document.querySelector(`#${pageId}`).style.visibility = "visible";
}

//Page Controllers
rhit.SigninPageController = class {
	constructor() {
		document.querySelector("#roseSSO").addEventListener("click", (event) => {
			rhit.fbAuth.signIn();
		});
	}
}

rhit.ProfilePageController = class {
	constructor() {
		//Make sure this user is real
		rhit._ensureUserIsValid();

		//Initialize buttons
		rhit._initializeSidebar();
		rhit._intializeStarButtons();
		document.querySelector("#editIcon").onclick = (event) => {
			window.location.href = `/profileEditing.html?uid=${rhit.fbAuth.uid}`
		}
		document.querySelector("#postHistoryMore").onclick = (event) => {
			window.location.href = `/posts.html?uid=${rhit.fbUserManager._uid}`;
		}

		//Follow button functionality
		rhit._initializeFollowButton(this.updateView.bind(this));

		//Start firebase managers
		rhit.fbUserManager.beginListening(this.updateView.bind(this));
		rhit.fbPostsManager.beginListening(this.updateView.bind(this));
	}
	updateView(caller) {

		//HTML elements
		let profileInfo = rhit.fbUserManager.profileInfo;
		let nameLabel = document.querySelector("#profileName");
		let profilePicture = document.querySelector("#profileImage");
		let postsContainer = document.querySelector("#postHistoryContainer");
		let postLabel = document.querySelector("#postHistoryLabel");
		let postOne = document.querySelector("#postOne");
		let postTwo = document.querySelector("#postTwo");
		let morePostsButton = document.querySelector("#postHistoryMore");
		let moderatorIcon = document.querySelector("#moderatorIcon");
		let bio = document.querySelector("#bioField");
		let communityRatingLabel = document.querySelector("#ratingLabel");
		let stars = [document.querySelector("#star1Button"),
					 document.querySelector("#star2Button"),
					 document.querySelector("#star3Button"),
					 document.querySelector("#star4Button"),
					 document.querySelector("#star5Button")];
		let editIcon = document.querySelector("#editIcon");
		let messageButton = document.querySelector("#messageButton");

		//Handle user listener updates
		if(caller==rhit.FB_USER_CALLER) {
			console.log("Called user");

			//Update profile info accordingly
			if(rhit.fbAuth.uid != rhit.fbUserManager._uid) {
				editIcon.style.visibility = "hidden";
			}
			nameLabel.innerHTML = profileInfo.name;
			if(profileInfo.profileImgUrl!=null) {
				profilePicture.src = profileInfo.profileImgUrl;
			}
			if(profileInfo.isModerator) {
				nameLabel.innerHTML = `<span id="moderatorIcon" class="material-icons">shield</span>${profileInfo.name}`;
			}
			bio.innerHTML = profileInfo.bio;
			communityRatingLabel.innerHTML = `Community rating: ${profileInfo.rating}`;
			if(rhit.fbAuth.uid==rhit.fbUserManager._uid) {
				messageButton.style.visibility = "hidden";
			}

			//Rating functionality
			if(rhit.fbUserManager.hasRatedThisUser) {
				document.querySelector("#starInfo").style.display = "none";
				let rating = rhit.fbUserManager.getRatingFromUser(rhit.fbAuth.uid);
				let starContainer = stars[0].parentElement;
				switch(rating) {
					case 1:
						starContainer.innerHTML = `
						<img id="star1Button" class="clickable star" src="images/yellow_star.png" alt="star1">
						<img id="star2Button" class="clickable star" src="images/A_star.png" alt="star2">
						<img id="star3Button" class="clickable star" src="images/A_star.png" alt="star3">
						<img id="star4Button" class="clickable star" src="images/A_star.png" alt="star4">
						<img id="star5Button" class="clickable star" src="images/A_star.png" alt="star5">
						`;
						break;
					case 2:
						starContainer.innerHTML = `
						<img id="star1Button" class="clickable star" src="images/yellow_star.png" alt="filled star1">
						<img id="star2Button" class="clickable star" src="images/yellow_star.png" alt="filled star2">
						<img id="star3Button" class="clickable star" src="images/A_star.png" alt="star3">
						<img id="star4Button" class="clickable star" src="images/A_star.png" alt="star4">
						<img id="star5Button" class="clickable star" src="images/A_star.png" alt="star5">
						`;
						break;
					case 3:
						starContainer.innerHTML = `
						<img id="star1Button" class="clickable star" src="images/yellow_star.png" alt="filled star1">
						<img id="star2Button" class="clickable star" src="images/yellow_star.png" alt="filled star2">
						<img id="star3Button" class="clickable star" src="images/yellow_star.png" alt="filled star3">
						<img id="star4Button" class="clickable star" src="images/A_star.png" alt="star4">
						<img id="star5Button" class="clickable star" src="images/A_star.png" alt="star5">
						`;
						break;
					case 4:
						starContainer.innerHTML = `
						<img id="star1Button" class="clickable star" src="images/yellow_star.png" alt="filled star1">
						<img id="star2Button" class="clickable star" src="images/yellow_star.png" alt="filled star2">
						<img id="star3Button" class="clickable star" src="images/yellow_star.png" alt="filled star3">
						<img id="star4Button" class="clickable star" src="images/yellow_star.png" alt="filled star4">
						<img id="star5Button" class="clickable star" src="images/A_star.png" alt="star5">
						`;
						break;
					case 5:
						starContainer.innerHTML = `
						<img id="star1Button" class="clickable star" src="images/yellow_star.png" alt="filled star1">
						<img id="star2Button" class="clickable star" src="images/yellow_star.png" alt="filled star2">
						<img id="star3Button" class="clickable star" src="images/yellow_star.png" alt="filled star3">
						<img id="star4Button" class="clickable star" src="images/yellow_star.png" alt="filled star4">
						<img id="star5Button" class="clickable star" src="images/yellow_star.png" alt="filled star5">
						`;
						break;
				}

				//Reinitialize star buttons
				rhit._intializeStarButtons();
			} else {
				document.querySelector("#starInfo").style.display = "block";
			}

			//Update following button
			rhit.fbUserManager.isFollowingUser().
			then((followingStatus) => {
				if(followingStatus) {
					document.querySelector("#followButton").innerHTML = "Following";
				} else {
					document.querySelector("#followButton").innerHTML = "Follow";
				}
			});

			rhit._initializeFollowButton();

			document.querySelector("#messageButton").onclick = () => {
				window.location.href = `/messageDetail.html?oid=${rhit.fbUserManager._uid}`;
			}
			rhit._showPage("profilePage");
		}

		//Handle post listener updates
		if(caller==rhit.FB_POSTS_CALLER) {
			console.log("Called by posts");
			//Turn all posts back on
			let posts = rhit.fbPostsManager.getPostsFromUser(rhit.fbUserManager._uid);
			postsContainer.style.display = "flex";
			postOne.style.display = "flex";
			postTwo.style.display = "flex";
			postLabel.style.display = "block";
			morePostsButton.style.display = "block";
			postOne.onclick = null;
			postTwo.onclick = null;

			//Hide appropriate fields and fill in info
			let numPosts = rhit.fbPostsManager.numberOfPostsFromUser(rhit.fbUserManager._uid);
			if(numPosts==0) {
				postsContainer.style.display = "none";
				postLabel.style.display = "none";
			} else if(numPosts==1) {
				postTwo.style.display = "none";
				morePostsButton.style.display = "none";
				document.querySelector("#post1Title").innerHTML = posts[0].title;
				document.querySelector("#post1Img").src = posts[0].imageUrl;
				postOne.onclick = () => {
					window.location.href = `/postDetail.html?id=${posts[0].id}`
				}
			} else if(numPosts==2) {
				morePostsButton.style.display = "none";
				document.querySelector("#post1Title").innerHTML = posts[0].title;
				document.querySelector("#post1Img").src = posts[0].imageUrl;
				document.querySelector("#post2Title").innerHTML = posts[1].title;
				document.querySelector("#post2Img").src = posts[1].imageUrl;
				postOne.onclick = () => {
					window.location.href = `/postDetail.html?id=${posts[0].id}`
				}
				postTwo.onclick = () => {
					window.location.href = `/postDetail.html?id=${posts[1].id}`
				}
			} else {
				document.querySelector("#post1Title").innerHTML = posts[0].title;
				document.querySelector("#post1Img").src = posts[0].imageUrl;
				document.querySelector("#post2Title").innerHTML = posts[1].title;
				document.querySelector("#post2Img").src = posts[1].imageUrl;
				postOne.onclick = () => {
					window.location.href = `/postDetail.html?id=${posts[0].id}`
				}
				postTwo.onclick = () => {
					window.location.href = `/postDetail.html?id=${posts[1].id}`
				}
			}
		}
	}
}

rhit.ProfileEditingPageController = class {
	constructor() {
		rhit._ensureUserIsValid();
		rhit._initializeSidebar();

		let fileInput = document.querySelector("#fileInput");
		let pfpImg = document.querySelector("#profileImage");

		rhit.fbUserManager.getProfileInfoAsync().then((profileInfo) => {
			if(profileInfo.profileImgUrl!=null) {
				pfpImg.src = profileInfo.profileImgUrl;
			}
			if(profileInfo.isModerator) {
				document.querySelector("#profileName").innerHTML = `<span id="moderatorIcon" class="material-icons">shield</span>${profileInfo.name}`;
			}
			document.querySelector("#bioField").innerHTML = profileInfo.bio;
		});

		pfpImg.onclick = (event) => {
			fileInput.click();
		}
		fileInput.addEventListener("change", (event) => {
			const reader = new FileReader();
			reader.onload = (event) => {
				pfpImg.src = event.target.result;
			}
			reader.readAsDataURL(fileInput.files[0]);
		});

		$('#editBioModal').on('shown.bs.modal', function () {
			document.querySelector("#newBioInput").value = document.querySelector("#bioField").innerHTML;
		});
		document.querySelector("#saveButton").onclick = () => {
			document.querySelector("#bioField").innerHTML = document.querySelector("#newBioInput").value;
		}

		document.querySelector("#doneButton").onclick = (event) => {
			console.log("Done clicked!");
			if(fileInput.files[0]) {
				this._uploadImageToStorage(fileInput.files[0]).then((url) => {
					rhit.fbUserManager.updateProfileImage(url);
					rhit.fbUserManager.updateBio(document.querySelector("#bioField").innerHTML).then(() => {
						window.location.href = `/profile.html?uid=${rhit.fbUserManager._uid}`;
					});
				});
			} else {
				console.log("No file uploaded!");
				rhit.fbUserManager.updateBio(document.querySelector("#bioField").innerHTML).then(() => {
					window.location.href = `/profile.html?uid=${rhit.fbUserManager._uid}`;
				});
			}
		}

		document.querySelector("#cancelButton").onclick = () => {
			window.location.href = `/profile.html?uid=${rhit.fbUserManager._uid}`;
		}

		rhit._showPage("profileEditingPage");
	}

	async _uploadImageToStorage(file) {
		let ref = firebase.storage().ref();
		let newImageRef = ref.child(`images/${rhit.fbAuth.uid} - ${file.name}`);
		let snapshot = await newImageRef.put(file);
		let URL = await snapshot.ref.getDownloadURL();
		return URL;
	}
}

rhit.PostsPageContoller = class {
	constructor(uid, tags) {
		this._tags = tags;
		if(uid) {
			rhit._ensureUserIsValid();
			rhit.fbUserManager.getProfileInfoAsync().then((profileInfo) => {
				document.querySelector("#postPageOwner").innerHTML = `${profileInfo.name}'s posts`;
			});
			document.querySelector("#fab").style.display = "none";
		} else if(this._tags.length!=0) {
			document.querySelector("#fab").style.display = "none";
			document.querySelector("#postPageOwner").style.display = "none";
			document.getElementById("clearFiltersButton").style.display = "block";
		} else {
			document.querySelector("#postPageOwner").style.display = "none";
		}
		rhit._initializeSidebar();		
		this._uid = uid;
		document.getElementById("clearFiltersButton").onclick = (event) => {
			window.location.href = "/posts.html";
		};
		document.querySelector("#search").onclick = (event) => {
			window.location.href = "/filters.html";
		}
		rhit.fbPostsManager.beginListening(this.updateView.bind(this));
	}

	updateView() {
		let posts = null;
		if(this._uid) {
			posts = rhit.fbPostsManager.getPostsFromUser(this._uid);
		} else if(this._tags.length!=0) {
			posts = rhit.fbPostsManager.getPostsWithTags(this._tags);
		} else {
			posts = rhit.fbPostsManager.getPosts();
		}
		let postContainer = document.querySelector("#postContainer");
		postContainer.innerHTML = "";
		for(let i = 0; i < posts.length; i++) {
			let newPost = this._createPostElement(posts[i]);
			newPost.onclick = (event) => {
				window.location.href = `/postDetail.html?id=${posts[i].id}`;
			}
			postContainer.appendChild(newPost);
		}
		document.querySelector("#fab").onclick = (event) => {
			window.location.href = "/createPost.html";
		}
		rhit._showPage("postsPage");
	}

	_createPostElement(postInfo) {
		return htmlToElement(`
		<div class="col-6">
              <div id="${postInfo.id}" class="card clickable">
                <div class="tackContainer">
                  <img class="card-img-top" src="${postInfo.imageUrl}" alt="Card image cap">
                  <img class="tack" src="images/thumbtack_transparent.png" alt="tack">
                </div>
                <div class="card-body">
                  <h5 class="card-title">${postInfo.title}</h5>
                </div>
              </div>
        </div>
		`);
	}
}

rhit.PostDetailPageController = class {
	constructor(uid, id) {
		rhit._initializeSidebar();
		if(uid!=rhit.fbAuth.uid) {
			document.querySelector("#editIcon").style.display = "none";
		}
		document.querySelector("#editIcon").onclick = (event) => {
			window.location.href = `/editPost.html?id=${id}`;
		};
		rhit.fbSinglePostManager.beginListening(this.updateView.bind(this));
		rhit.fbUserManager.beginListening(this.updateView.bind(this));
	}

	updateView(caller) {
		if(caller==rhit.FB_SINGLE_POST_CALLER) {
			let postInfo = rhit.fbSinglePostManager._createPostObjectFromDoc(rhit.fbSinglePostManager._documentSnapshot);
			document.querySelector("#postImage").src = postInfo.imageUrl;
			document.querySelector("#descriptionField").innerHTML = postInfo.description;
			let hashtagContainer = document.querySelector("#tagContainer");
			hashtagContainer.innerHTML = "";
			for(let i = 0; i < postInfo.hashtags.length; i++) {
				if(postInfo.hashtags[i] != "") {
					let tag = postInfo.hashtags[i];
					let tagElement = this._createHashtagElement(tag);
					hashtagContainer.appendChild(tagElement);
				}
			}
			if(hashtagContainer.innerHTML == "") {
				document.querySelector("#tagLabel").style.display = "none";
			} else {
				document.querySelector("#tagLabel").style.display = "block";
			}
			rhit._showPage("postDetailPage");
		} else if(caller==rhit.FB_USER_CALLER) {
			let profileInfo = rhit.fbUserManager.profileInfo;
			document.querySelector("#miniProfileImage").src = profileInfo.profileImgUrl;
			document.querySelector("#authorText").innerHTML = profileInfo.name;
			document.querySelector("#imageAuthorContainerInner").onclick = (event) => {
				window.location.href = `/profile.html?uid=${rhit.fbUserManager._uid}`;
			}
		}
	}

	_createHashtagElement(tag) {
		return htmlToElement(`
		<div class="hashtag">${tag}</div>
		`);
	}
}

rhit.PostCreationPageController = class {
	constructor() {
		rhit._initializeSidebar();
		let fileInput = document.querySelector("#fileInput");
		document.querySelector("#postImage").onclick = (event) => {
			fileInput.click();
		}
		let imgFile = null;
		fileInput.addEventListener("change", (event) => {
			const reader = new FileReader();
			reader.onload = (event) => {
				document.querySelector("#postImage").src = event.target.result;
			}
			imgFile = fileInput.files[0];
			reader.readAsDataURL(fileInput.files[0]);
		});
		document.querySelector("#titleSaveButton").onclick = (event) => {
			let input = document.querySelector("#titleInput").value.trim();
			document.querySelector("#titleField").innerHTML = input;
		}
		document.querySelector("#hashtagSaveButton").onclick = (event) => {
			console.log("clicked!");
			let tag = document.querySelector("#hashtagInput").value;
			let tagElement = this._createHashtagElement(tag);
			tagElement.onclick = (event) => {
				event.target.remove();
			}
			let tagContainer = document.querySelector("#tagContainer");
			tagContainer.prepend(tagElement);
		};
		document.querySelector("#descriptionSaveButton").onclick = (event) => {
			document.querySelector("#descriptionField").innerHTML = document.querySelector("#descriptionInput").value;
		}
		document.querySelector("#cancelButton").onclick = (event) => {
			window.location.href = "/posts.html";
		};
		document.querySelector("#createPostButton").onclick = (event) => {
			let title = document.querySelector("#titleField").innerHTML;
			let description = document.querySelector("#descriptionField").innerHTML;
			let tags = [];
			let dateSelection = document.querySelector("#date").value;
			let timeSelection = document.querySelector("#time").value;
			let tagEls = document.querySelector("#tagContainer").getElementsByTagName("*");
			for(let i = 0; i < tagEls.length; i++) {
				if(tagEls[i].id != "addNewTag") {
					tags.push(tagEls[i].innerHTML);
				}
			}
			if(title == "Add a short title here") {
				alert("You must add a title!");
				return;
			}
			if(title.length > 20) {
				alert("Title must be 20 characters or less!");
				return;
			}
			if(description == "Describe your event") {
				alert("You must add a description!");
				return;
			}
			if(!dateSelection) {
				alert("You must select an expiration date!");
				return;
			}
			if(!timeSelection) {
				alert("You must select an expiration time!");
				return;
			}
			let dateObj = new Date(`${dateSelection}T${timeSelection}`);
			let fbDate = firebase.firestore.Timestamp.fromDate(dateObj);
			if(imgFile) {
				this._uploadImageToStorage(imgFile).then((url) => {
					rhit.fbPostsManager.addPost(title, description, url, tags, fbDate).then(() => {
						window.location.href = "/posts.html";
					});
				});
			} else {
				alert("You must upload an image!");
				return;
			}
		}
	}

	_createHashtagElement(tag) {
		return htmlToElement(`
		<div class="hashtag clickable removeable">${tag}</div>
		`);
	}

	async _uploadImageToStorage(file) {
		let ref = firebase.storage().ref();
		let newImageRef = ref.child(`postImages/${rhit.fbAuth.uid} - ${file.name}`);
		let snapshot = await newImageRef.put(file);
		let URL = await snapshot.ref.getDownloadURL();
		return URL;
	}
}

rhit.FiltersPageController = class {
	constructor() {
		rhit._initializeSidebar();
		document.querySelector("#hashtagSaveButton").onclick = (event) => {
			console.log("clicked!");
			let tag = document.querySelector("#hashtagInput").value;
			let tagElement = this._createHashtagElement(tag);
			tagElement.onclick = (event) => {
				event.target.remove();
			}
			let tagContainer = document.querySelector("#tagContainer");
			tagContainer.prepend(tagElement);
		};
		document.querySelector("#searchButton").onclick = (event) => {
			let tags = [];
			let tagEls = document.querySelector("#tagContainer").getElementsByTagName("*");
			for(let i = 0; i < tagEls.length; i++) {
				if(tagEls[i].id != "addNewTag") {
					tags.push(tagEls[i].innerHTML);
				}
			}
			let searchString = "";
			if(tags[0]) {
				searchString = `?tag=${tags[0]}`;
			} else {
				window.location.href = "/posts.html";
			}
			for(let i = 1; i < tags.length; i++) {
				searchString+=`&tag=${tags[i]}`;
			}
			window.location.href = "/posts.html" + searchString;
		}
	}

	_createHashtagElement(tag) {
		return htmlToElement(`
		<div class="hashtag clickable removeable">${tag}</div>
		`);
	}
}

rhit.EditPostPageController = class {
	constructor(id) {
		rhit.fbPostsManager.getPostWithIdAsync(id).then( postInfo => {
			document.querySelector("#titleField").innerHTML = postInfo.title;
			document.querySelector("#descriptionField").innerHTML = postInfo.description;
			document.querySelector("#descriptionInput").value = postInfo.description;
			document.querySelector("#titleInput").value = postInfo.title;
			let hashtagContainer = document.querySelector("#tagContainer");
			for(let i = 0; i < postInfo.hashtags.length; i++) {
				if(postInfo.hashtags[i] != "") {
					let tag = postInfo.hashtags[i];
					let tagElement = this._createHashtagElement(tag);
					tagElement.onclick = (event) => {
						event.target.remove();
					}
					hashtagContainer.prepend(tagElement);
				}
			}
			document.querySelector("#hashtagSaveButton").onclick = (event) => {
				console.log("clicked!");
				let tag = document.querySelector("#hashtagInput").value;
				let tagElement = this._createHashtagElement(tag);
				tagElement.onclick = (event) => {
					event.target.remove();
				}
				let tagContainer = document.querySelector("#tagContainer");
				tagContainer.prepend(tagElement);
			};
			document.querySelector("#cancelButton").onclick = (event) => {
				window.location.href = `/postDetail.html?id=${id}`;
			};
			document.querySelector("#descriptionSaveButton").onclick = (event) => {
				document.querySelector("#descriptionField").innerHTML = document.querySelector("#descriptionInput").value;
			};
			document.querySelector("#titleSaveButton").onclick = (event) => {
				let input = document.querySelector("#titleInput").value.trim();
				document.querySelector("#titleField").innerHTML = input;
			};
			document.querySelector("#deletePostButton").onclick = (event) => {
				rhit.fbPostsManager.deletePost(id).then(() => {
					window.location.href = "/posts.html";
				});
			}
			document.querySelector("#doneButton").onclick = (event) => {
				let tags = [];
				let tagEls = document.querySelector("#tagContainer").getElementsByTagName("*");
				for(let i = 0; i < tagEls.length; i++) {
					if(tagEls[i].id != "addNewTag") {
						tags.push(tagEls[i].innerHTML);
					}
				}
				rhit.fbPostsManager.updatePost(id, document.querySelector("#descriptionInput").value, document.querySelector("#titleInput").value, tags).then(() => {
					window.location.href = `/postDetail.html?id=${id}`;
				});
			};
			rhit._initializeSidebar();
			rhit._showPage("editPostPage");
		});
	}

	_createHashtagElement(tag) {
		return htmlToElement(`
		<div class="hashtag clickable removeable">${tag}</div>
		`);
	}
}

rhit.MessageListPageController = class {
	constructor() {
		rhit._initializeSidebar();
		rhit.fbUserManager.beginListening(this.updateView.bind(this));
	}

	updateView() {
		let messagesContainer = document.querySelector("#messagesContainer");
		rhit.fbUserManager.getProfileInfoAsync().then((profileInfo) => {
			let uids = profileInfo.hasMessagesWith;
			messagesContainer.innerHTML = "";
			for(let i = 0; i < profileInfo.hasMessagesWith.length; i++) {
				rhit.fbUserManager.getProfileInfoFromId(uids[i]).then((profileInfoI) => {
					let newMsgElem = htmlToElement(`
					<div class="card clickable" style="width: 100%;">
						<div class="card-body">
							<div class="card-text">
								<div id="miniPfpContainer2">
									<img class="miniProfileImage2" src="${profileInfoI.profileImgUrl}" alt="pfp">&nbsp;&nbsp;</img>
								</div>
								<div class="inline-block name">${profileInfoI.name}</div>
							</div>
						</div>
					</div>
					`);
					newMsgElem.onclick = (event) => {
						window.location.href = `/messageDetail.html?oid=${uids[i]}`;
					}
					messagesContainer.appendChild(newMsgElem);
				});
			};
			rhit._showPage("messageListPage");
		});
	}
}

rhit.MessageDetailPageController = class {
	constructor() {
		rhit._initializeSidebar();
		document.querySelector("#profileImage").onclick = (event) => {
			window.location.href = `/profile.html?uid=${rhit.fbUserManager._uid}`;
		};
		document.querySelector("#profileName2").onclick = (event) => {
			window.location.href = `/profile.html?uid=${rhit.fbUserManager._uid}`;
		};
		document.querySelector("#sendMessage").onclick = (event) => {
			let messageInput = document.querySelector("#newMessageInput");
			rhit.fbMessageManager.sendMessage(messageInput.value);
			messageInput.value = "";
		}
		rhit.fbMessageManager.beginListening(this.updateView.bind(this));
		rhit.fbUserManager.beginListening(this.updateView.bind(this));
	}

	updateView(caller) {
		if(caller == rhit.FB_MESSAGE_CALLER) { 
			let messages = rhit.fbMessageManager.getMessages();
			let messageContainer = document.querySelector("#messagesContainer");
			messageContainer.innerHTML = "";
			for(let i = 0; i < messages.length; i++) {
				messageContainer.appendChild(this._createCard(messages[i]));
			}
			rhit._showPage("messageDetailPage");
		} else if(caller == rhit.FB_USER_CALLER) {
			let info = rhit.fbUserManager.profileInfo;
			document.querySelector("#profileImage").src = info.profileImgUrl;
			if(info.isModerator) { 
				document.querySelector("#profileName2").innerHTML = `<span id="moderatorIcon2" class="material-icons">shield</span>${info.name}`;
			} else {
				document.querySelector("#profileName2").innerHTML = info.name;
			}
		}
	}

	_createCard(str) {
		let uid = str.split("-")[0];
		let msg = str.split("-")[1];

		if(uid == rhit.fbAuth.uid) {
			return htmlToElement(`
			<div class="row">
				<div class="col-9 ml-auto">
					<div class="card message">
						<div class="card-body">
							<div>${msg}</div>
						</div>
					</div>
				</div>
		    </div>
			`);
		} else {
			return htmlToElement(`
			<div class="row">
				<div class="col-9">
					<div class="card message left">
						<div class="card-body">
							<div>${msg}</div>
						</div>
					</div>
				</div>
		    </div>
			`);
		}
	}
}

rhit.FollowingPageController = class {
	constructor() {
		rhit._initializeSidebar();
		rhit.fbUserManager.beginListening(this.updateView.bind(this));
	}

	updateView() {
		let followingContainer = document.querySelector("#followingContainer");
		rhit.fbUserManager.getProfileInfoAsync().then((profileInfo) => {
			let uids = profileInfo.following;
			followingContainer.innerHTML = "";
			for(let i = 0; i < uids.length; i++) {
				rhit.fbUserManager.getProfileInfoFromId(uids[i]).then((profileInfoI) => {
					let newFollowingElem = htmlToElement(`
					<div class="card clickable" style="width: 100%;">
						<div class="card-body">
							<div class="card-text">
								<div id="miniPfpContainer2">
									<img class="miniProfileImage2" src="${profileInfoI.profileImgUrl}" alt="pfp">&nbsp;&nbsp;</img>
								</div>
								<div class="inline-block name">${profileInfoI.name}</div>
							</div>
						</div>
					</div>
					`);
					newFollowingElem.onclick = (event) => {
						window.location.href = `/profile.html?uid=${uids[i]}`;
					}
					followingContainer.appendChild(newFollowingElem);
				});
			};
			rhit._showPage("followingPage");
		});
	}
}

//Firebase classes
rhit.FBAuth = class {
	constructor() {
		this._user = null;
	}
	beginListening(changeListener) {
		firebase.auth().onAuthStateChanged((user) => {
			this._user = user;
			changeListener();
		})
	}
	signIn() {
		Rosefire.signIn("00ee0af1-ccee-41da-b7bd-9c0ff323257e", (err, rfUser) => {
			if (err) {
			  console.log("Rosefire error!", err);
			  return;
			}
			console.log("Rosefire success!", rfUser);
			firebase.auth().signInWithCustomToken(rfUser.token)
			.then((userCredential) => {
				let user = userCredential.user;
				let isNewUser = user.metadata.creationTime === user.metadata.lastSignInTime;
				if(isNewUser) {
					console.log("Creating user profile in firestore!");
					rhit._initializeFirstTimeUser(rfUser);
				}
			})
			.catch((err) => {
				console.error("Error signing into firebase", err);
			});
		  });
		  
	}
	signOut() {
		firebase.auth().signOut();
	}
	get uid() {
		return this._user.uid;
	}
	get isSignedIn() {
		return !!this._user;
	}
}

rhit.FBUserManager = class {
	constructor(uid) {
		this._ref = firebase.firestore().collection(rhit.FB_KEY_USERS_COLLECTION).doc(uid);
		this._uid = uid;
		this._documentSnapshot = null;
	}
	beginListening(changeListener) {
		this._ref.onSnapshot((doc) => {
			this._documentSnapshot = doc;
			changeListener(rhit.FB_USER_CALLER);
		});
	}
	updateBio(newBio) {
		return this._ref.update({
			[rhit.FB_KEY_USERS_BIO]: newBio,
			[rhit.FB_KEY_USERS_LAST_EDITED]: firebase.firestore.Timestamp.now() 
		});
	}
	updateProfileImage(newUrl) {
		this._ref.update({
			[rhit.FB_KEY_USERS_PROFILE_IMG_SRC]: newUrl,
			[rhit.FB_KEY_USERS_LAST_EDITED]: firebase.firestore.Timestamp.now() 
		});
	}
	promote() {

	}
	follow() {
		return firebase.firestore().collection(rhit.FB_KEY_USERS_COLLECTION).doc(rhit.fbAuth.uid).get()
		.then((doc) => {
			let oldFollowing = doc.get(rhit.FB_KEY_USERS_FOLLOWING);
			oldFollowing.push(this._uid);
			firebase.firestore().collection(rhit.FB_KEY_USERS_COLLECTION).doc(rhit.fbAuth.uid).update({
				[rhit.FB_KEY_USERS_FOLLOWING]: oldFollowing
			})
		})
		.catch((err) => {
			console.error("Error following user", err);
		})
	}
	unfollow() {
		return firebase.firestore().collection(rhit.FB_KEY_USERS_COLLECTION).doc(rhit.fbAuth.uid).get()
		.then((doc) => {
			let oldFollowing = doc.get(rhit.FB_KEY_USERS_FOLLOWING);
			oldFollowing.splice(oldFollowing.indexOf(this._uid), 1);
			firebase.firestore().collection(rhit.FB_KEY_USERS_COLLECTION).doc(rhit.fbAuth.uid).update({
				[rhit.FB_KEY_USERS_FOLLOWING]: oldFollowing
			})
		})
		.catch((err) => {
			console.error("Error unfollowing user", err);
		})
	}
	updateRating(newRating) {
		let newKeyPair = this._documentSnapshot.get(rhit.FB_KEY_USERS_RATINGS);
		newKeyPair[rhit.fbAuth.uid] = newRating;
		this._ref.update({
			[rhit.FB_KEY_USERS_RATINGS]: newKeyPair
		});
	}
	delete() {

	}
	_documentPromise() {
		return this._ref.get();
	}
	getRatingFromUser(uid) {
		return parseInt(this._documentSnapshot.get(rhit.FB_KEY_USERS_RATINGS)[uid]);
	}
	async isFollowingUser() {
		try {
			const doc = await firebase.firestore().collection(rhit.FB_KEY_USERS_COLLECTION).doc(rhit.fbAuth.uid).get()
			return doc.get(rhit.FB_KEY_USERS_FOLLOWING).includes(this._uid);
		} catch(err) {
			console.error("Error checking user following status:", err);
		} 
	}
	async getProfileInfoAsync() {
		let documentSnapshot = await this._ref.get();
		return {name: documentSnapshot.get(rhit.FB_KEY_USERS_NAME), 
			rating: rhit._averageRatings(rhit._convertMapToNumberArray(documentSnapshot.get(rhit.FB_KEY_USERS_RATINGS))),
			profileImgUrl: documentSnapshot.get(rhit.FB_KEY_USERS_PROFILE_IMG_SRC),
			bio: documentSnapshot.get(rhit.FB_KEY_USERS_BIO),
			following: documentSnapshot.get(rhit.FB_KEY_USERS_FOLLOWING),
			isModerator: documentSnapshot.get(rhit.FB_KEY_USERS_IS_MODERATOR), 
			hasMessagesWith: documentSnapshot.get(rhit.FB_KEY_USERS_HAS_MESSAGES)};
	}
	async getProfileInfoFromId(id) {
		let documentSnapshot = await firebase.firestore().collection(rhit.FB_KEY_USERS_COLLECTION).doc(id).get();
		return {name: documentSnapshot.get(rhit.FB_KEY_USERS_NAME), 
			rating: rhit._averageRatings(rhit._convertMapToNumberArray(documentSnapshot.get(rhit.FB_KEY_USERS_RATINGS))),
			profileImgUrl: documentSnapshot.get(rhit.FB_KEY_USERS_PROFILE_IMG_SRC),
			bio: documentSnapshot.get(rhit.FB_KEY_USERS_BIO),
			following: documentSnapshot.get(rhit.FB_KEY_USERS_FOLLOWING),
			isModerator: documentSnapshot.get(rhit.FB_KEY_USERS_IS_MODERATOR), 
			hasMessagesWith: documentSnapshot.get(rhit.FB_KEY_USERS_HAS_MESSAGES)};
	}
	get profileInfo() {
		return {name: this._documentSnapshot.get(rhit.FB_KEY_USERS_NAME), 
				rating: rhit._averageRatings(rhit._convertMapToNumberArray(this._documentSnapshot.get(rhit.FB_KEY_USERS_RATINGS))),
				profileImgUrl: this._documentSnapshot.get(rhit.FB_KEY_USERS_PROFILE_IMG_SRC),
				bio: this._documentSnapshot.get(rhit.FB_KEY_USERS_BIO),
				following: this._documentSnapshot.get(rhit.FB_KEY_USERS_FOLLOWING),
				isModerator: this._documentSnapshot.get(rhit.FB_KEY_USERS_IS_MODERATOR),
		};
	}
	get hasRatedThisUser() {
		if(this._documentSnapshot.get(rhit.FB_KEY_USERS_RATINGS)[rhit.fbAuth.uid]) {
			return true;
		}
		return false;
	}

	async getThisUserExists(uid) {
		let doc = await firebase.firestore().collection(rhit.FB_KEY_USERS_COLLECTION).doc(uid).get();
		return doc.exists;
	}

	addMessagePair(oid) {
		firebase.firestore().collection(rhit.FB_KEY_USERS_COLLECTION).doc(rhit.fbAuth.uid).get().then((doc) => {
			let oldMessages = doc.get(rhit.FB_KEY_USERS_HAS_MESSAGES);
			oldMessages.push(oid);
			firebase.firestore().collection(rhit.FB_KEY_USERS_COLLECTION).doc(rhit.fbAuth.uid).update({
				[rhit.FB_KEY_USERS_HAS_MESSAGES]: oldMessages
			});
		});
		firebase.firestore().collection(rhit.FB_KEY_USERS_COLLECTION).doc(oid).get().then((doc) => {
			let oldMessages = doc.get(rhit.FB_KEY_USERS_HAS_MESSAGES);
			oldMessages.push(rhit.fbAuth.uid);
			firebase.firestore().collection(rhit.FB_KEY_USERS_COLLECTION).doc(oid).update({
				[rhit.FB_KEY_USERS_HAS_MESSAGES]: oldMessages
			});
		});
	}
}

rhit.FBPostsManager = class {
	constructor() {
		this._ref = firebase.firestore().collection(rhit.FB_KEY_POSTS_COLLECTION);
		this._documentSnapshots = null;
	}
	beginListening(changeListener) {
		this._ref.orderBy(rhit.FB_KEY_POSTS_LAST_EDITED, 'desc').onSnapshot((querySnapshot) => {
			this._documentSnapshots = querySnapshot;
			changeListener(rhit.FB_POSTS_CALLER);
		});
	}
	numberOfPostsFromUser(uid) {
		let count = 0;
		this._documentSnapshots.forEach((doc) => {
			if(doc.get(rhit.FB_KEY_POSTS_AUTHOR) == uid) {
				count++;
			}
		});
		return count;
	}
	getPostsFromUser(uid) {
		let userPosts = [];
		for(let i = 0; i < this._documentSnapshots.size; i++) {
			if(this._documentSnapshots.docs[i].get(rhit.FB_KEY_POSTS_AUTHOR) == uid) {
				userPosts.push(this._createPostObjectFromDoc(this._documentSnapshots.docs[i]));
			}
		}
		return userPosts;
	}
	getPostsWithTags(tags) {
		console.log("Getting posts with tags:", tags);
		let applicablePosts = [];
		for(let i = 0; i < this._documentSnapshots.size; i++) {
			let postTags = this._documentSnapshots.docs[i].get(rhit.FB_KEY_POSTS_HASTAGS);
			for(let i = 0; i < postTags.length; i++) {
				postTags[i] = postTags[i].toLowerCase();
			}
			let thisPostApplies = true;
			for(let i = 0; i < tags.length; i++) {
				if(!postTags.includes(tags[i].toLowerCase())) {
					thisPostApplies = false;
					break;
				}
			}
			if(thisPostApplies) {
				applicablePosts.push(this._createPostObjectFromDoc(this._documentSnapshots.docs[i]));
			}
		}
		return applicablePosts;
	}
	async getPostWithIdAsync(id) {
		let post = await this._ref.doc(id).get();
		if(post.exists) {
			return this._createPostObjectFromDoc(post);
		} else {
			console.error("Document with that id does not exist! -getPostWithIdAsync");
			return(null);
		}
	}
	getPosts() {
		let posts = [];
		for(let i = 0; i < this._documentSnapshots.size; i++) {
			posts.push(this._createPostObjectFromDoc(this._documentSnapshots.docs[i]));
		}
		return posts;
	}
	_createPostObjectFromDoc(doc) {
		return {
			id: doc.id,
			author: doc.get(rhit.FB_KEY_POSTS_AUTHOR),
			description: doc.get(rhit.FB_KEY_POSTS_DESCRIPTION),
			hashtags: doc.get(rhit.FB_KEY_POSTS_HASTAGS),
			imageUrl: doc.get(rhit.FB_KEY_POSTS_IMAGE_URL),
			lastEdited: doc.get(rhit.FB_KEY_POSTS_LAST_EDITED),
			title: doc.get(rhit.FB_KEY_POSTS_TITLE)
		}
	}
	addPost(title, description, imgUrl, tags, expirationDate) {
		return this._ref.add({
			[rhit.FB_KEY_POSTS_AUTHOR]: rhit.fbAuth.uid,
			[rhit.FB_KEY_POSTS_DESCRIPTION]: description,
			[rhit.FB_KEY_POSTS_EXPIRATION]: expirationDate,
			[rhit.FB_KEY_POSTS_HASTAGS]: tags,
			[rhit.FB_KEY_POSTS_IMAGE_URL]: imgUrl,
			[rhit.FB_KEY_POSTS_LAST_EDITED]: firebase.firestore.Timestamp.now(),
			[rhit.FB_KEY_POSTS_TITLE]: title
		});
	}
	deletePost(id) {
		return this._ref.doc(id).delete();
	}
	updatePost(id, newDesc, newTitle, tags) {
		return this._ref.doc(id).update({
			[rhit.FB_KEY_POSTS_DESCRIPTION]: newDesc,
			[rhit.FB_KEY_POSTS_TITLE]: newTitle,
			[rhit.FB_KEY_POSTS_HASTAGS]: tags,
			[rhit.FB_KEY_POSTS_LAST_EDITED]: firebase.firestore.Timestamp.now()
		});
	}
}

rhit.FBSinglePostManager = class {
	constructor(id) {
		this._ref = firebase.firestore().collection(rhit.FB_KEY_POSTS_COLLECTION).doc(id);
		this._documentSnapshot = null;
	}
	beginListening(changeListener) {
		this._ref.onSnapshot((doc) => {
			this._documentSnapshot = doc;
			changeListener(rhit.FB_SINGLE_POST_CALLER);
		});
	}
	async getPost() {
		let post = await this._ref.get();
		if(!post.exists) {
			return null;
		}
		return this._createPostObjectFromDoc(post);
	}
	_createPostObjectFromDoc(doc) {
		return {
			id: doc.id,
			author: doc.get(rhit.FB_KEY_POSTS_AUTHOR),
			description: doc.get(rhit.FB_KEY_POSTS_DESCRIPTION),
			hashtags: doc.get(rhit.FB_KEY_POSTS_HASTAGS),
			imageUrl: doc.get(rhit.FB_KEY_POSTS_IMAGE_URL),
			lastEdited: doc.get(rhit.FB_KEY_POSTS_LAST_EDITED),
			title: doc.get(rhit.FB_KEY_POSTS_TITLE)
		}
	} 
}

rhit.FBMessageManager = class {
	constructor(oid) {
		this._oid = oid;
		firebase.firestore().collection(rhit.FB_KEY_MESSAGES_COLLECTION).doc(rhit.fbAuth.uid+"-"+oid).get().then((doc) => {
			if(!doc.exists) {
				firebase.firestore().collection(rhit.FB_KEY_MESSAGES_COLLECTION).doc(oid+"-"+rhit.fbAuth.uid).get().then((doc2) => {
					if(!doc2.exists) {
						rhit.fbUserManager.getThisUserExists(oid).then((exists) => {
							if(exists) {
								console.warn("No messages exist between this user pair, creating a new one!");
								firebase.firestore().collection(rhit.FB_KEY_MESSAGES_COLLECTION).doc(rhit.fbAuth.uid+"-"+oid).set({
									[rhit.FB_KEY_MESSAGES_MESSAGES]: []
								});
								this._ref = firebase.firestore().collection(rhit.FB_KEY_MESSAGES_COLLECTION).doc(rhit.fbAuth.uid+"-"+oid);
								rhit.fbUserManager.addMessagePair(oid);
							} else {
								console.error("No document was found for this user pair!");
								window.location.href = "/404.html";
							}
						});
						
					} else {
						this._ref = firebase.firestore().collection(rhit.FB_KEY_MESSAGES_COLLECTION).doc(oid+"-"+rhit.fbAuth.uid);
					}
				});
			} else {
				this._ref = firebase.firestore().collection(rhit.FB_KEY_MESSAGES_COLLECTION).doc(rhit.fbAuth.uid+"-"+oid);
			}
		});
	}

	beginListening(changeListener) {
		let waitForNotNull = setInterval(() => {
			if(this._ref!=null){
				console.log("Not null anymore, good!");
				this._ref.onSnapshot((doc) => {
					this._docSnap = doc;
					changeListener(rhit.FB_MESSAGE_CALLER);
				});
				clearInterval(waitForNotNull);
			} else {
				console.log("Still waiting for not null");
			}
		}, 100);
	}

	getMessages() {
		return this._docSnap.get(rhit.FB_KEY_MESSAGES_MESSAGES);
	}

	sendMessage(msg) {
		let oldMessages = this.getMessages();
		oldMessages.push(rhit.fbAuth.uid+"-"+msg);
		this._ref.update({
			[rhit.FB_KEY_MESSAGES_MESSAGES]: oldMessages 
		});
	}
}



//Helper method for average ratings
rhit._convertMapToNumberArray = (map) => {
	let newArr = [];
	for(const key in map) {
		newArr.push(map[key]);
	}
	return newArr;
}

//Averages user ratings so that stars are either whole or half
rhit._averageRatings = (arr) => {
	if(arr.length <= 0) {
		return 0;
	}
	let sum = 0;
	let items = 0;
	for(let i = 0; i < arr.length; i++) {
		items++;
		sum += parseInt(arr[i]);
	}
	let avg = sum/items;
	if(avg % 1 != 0) {
		let avgFirstPart = parseFloat((avg+"").split(".")[0])
		let avgDec = (avg+"").split(".")[1];
		if(avgDec.length < 2) {
			avgDec = avgDec + "00";
		}
		avgDec = parseInt(avgDec.slice(0, 2));
		if(avgDec < 25) {
			avg = avgFirstPart;
		} else if(avgDec >= 25 && avgDec < 50) {
			avg = avgFirstPart + 0.5;
		} else if(avgDec > 50 && avgDec < 75) {
			avg = avgFirstPart + 0.5;
		} else if(avgDec >= 75) {
			avg = avgFirstPart + 1;
		}
	}
	return avg;
}

rhit._initializeFirstTimeUser = (rfUser) => {
	firebase.firestore().collection(rhit.FB_KEY_USERS_COLLECTION).doc(rfUser.username).set({
		bio: "Update me!",
		campus: "RHIT",
		following: [],
		hasMessagesWith: [],
		isModerator: false,
		lastEdited: firebase.firestore.Timestamp.now(),
		name: rfUser.name,
		profileImgUrl: null,
		rating: {}
	});
}

//Misc

// From: https://stackoverflow.com/questions/494143/creating-a-new-dom-element-from-an-html-string-using-built-in-dom-methods-or-pro/35385518#35385518
function htmlToElement(html) {
	var template = document.createElement('template');
	html = html.trim();
	template.innerHTML = html;
	return template.content.firstChild;
}


//Main helpers
rhit.initializePage = () => {
	let params = new URLSearchParams(window.location.search);
	if(document.querySelector("#signInPage")) {
		new rhit.SigninPageController();
	} else if(document.querySelector("#profilePage")) {
		let uid = params.get("uid");
		if(!uid) {
			window.location.href = "/404.html";
		}
		rhit.fbUserManager = new rhit.FBUserManager(uid);
		rhit.fbPostsManager = new rhit.FBPostsManager();
		rhit.profilePageController = new rhit.ProfilePageController();
	} else if(document.querySelector("#profileEditingPage")) {
		let uid = params.get("uid");
		if(!uid) {
			window.location.href = "/404.html";
		}
		rhit.fbUserManager = new rhit.FBUserManager(uid);
		new rhit.ProfileEditingPageController();
	} else if(document.querySelector("#postsPage")) {
		let uid = params.get("uid");
		if(uid) {
			rhit.fbUserManager = new rhit.FBUserManager(uid);
		}
		let tags = params.getAll("tag");
		rhit.fbPostsManager = new rhit.FBPostsManager();
		new rhit.PostsPageContoller(uid, tags);
	} else if(document.querySelector("#postDetailPage")) {
		let id = params.get("id");
		if(!id) {
			window.location.href = "/404.html";
		}
		rhit.fbSinglePostManager = new rhit.FBSinglePostManager(id);
		rhit.fbSinglePostManager.getPost().then((postInfo) => {
			if(postInfo) {
				rhit.fbUserManager = new rhit.FBUserManager(postInfo.author);
				new rhit.PostDetailPageController(postInfo.author, id);
			} else {
				window.location.href = "/404.html";
			}
		});
	} else if(document.querySelector("#createPostPage")) {
		rhit.fbPostsManager = new rhit.FBPostsManager();
		new rhit.PostCreationPageController();
	} else if(document.querySelector("#filtersPage")) {
		new rhit.FiltersPageController();
	} else if(document.querySelector("#editPostPage")) {
		let id = params.get("id");
		if(!id) {
			window.location.href = "/404.html";
		}
		rhit.fbPostsManager = new rhit.FBPostsManager();
		new rhit.EditPostPageController(id);
	} else if(document.querySelector("#messageListPage")) {
		rhit.fbUserManager = new rhit.FBUserManager(rhit.fbAuth.uid);
		new rhit.MessageListPageController();
	} else if(document.querySelector("#messageDetailPage")) {
		let oid = params.get("oid");
		if(!oid) {
			window.location.href = "/404.html";
		}
		rhit.fbUserManager = new rhit.FBUserManager(oid);
		rhit.fbMessageManager = new rhit.FBMessageManager(oid);
		new rhit.MessageDetailPageController();
	} else if(document.querySelector("#followingPage")) {
		rhit.fbUserManager = new rhit.FBUserManager(rhit.fbAuth.uid);
		new rhit.FollowingPageController();
	}
}
rhit.checkForRedirects = () => {
	console.log("Signed in?", rhit.fbAuth.isSignedIn);
	if(rhit.fbAuth.isSignedIn && document.querySelector("#signInPage")) {
		window.location.href = `/profile.html?uid=${rhit.fbAuth.uid}`;
	}
	if(!rhit.fbAuth.isSignedIn && !document.querySelector("#signInPage")) {
		window.location.href = "/";
	}
}
rhit.monitorPosts = () => {
	firebase.firestore().collection(rhit.FB_KEY_POSTS_COLLECTION).get().then((querySnapshot) => {
		querySnapshot.forEach((doc) => {
			let docExpiry = doc.get(rhit.FB_KEY_POSTS_EXPIRATION).toDate();
			let now = new Date();
			if(now >= docExpiry) {
				firebase.firestore().collection(rhit.FB_KEY_POSTS_COLLECTION).doc(doc.id).delete();
			}
		});
	});
}

// Main
rhit.main = function () {
	setInterval(rhit.monitorPosts, 10000);
	rhit.fbAuth = new rhit.FBAuth();
	rhit.fbAuth.beginListening(() => {
		rhit.checkForRedirects();
		rhit.initializePage();
	});
	console.log("Ready");
};

rhit.main();
